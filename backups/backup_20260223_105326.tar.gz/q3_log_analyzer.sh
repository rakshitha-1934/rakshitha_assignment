#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: $0 logfile"
    exit 1
fi

LOGFILE=$1

if [ ! -f "$LOGFILE" ]; then
    echo "File not found."
    exit 1
fi

if [ ! -s "$LOGFILE" ]; then
    echo "Log file is empty."
    exit 1
fi

echo "=== LOG FILE ANALYSIS ==="
echo "Log File: $LOGFILE"

TOTAL=$(wc -l < "$LOGFILE")
echo "Total Entries: $TOTAL"

UNIQUE_COUNT=$(awk '{print $1}' "$LOGFILE" | sort -u | wc -l)
echo "Unique IP Addresses: $UNIQUE_COUNT"

awk '{print $1}' "$LOGFILE" | sort -u | sed 's/^/ - /'

echo "Status Code Summary:"
awk '{print $NF}' "$LOGFILE" | sort | uniq -c | awk '{print $2": "$1" requests"}'

echo "Most Frequently Accessed Page:"
awk '{print $7}' "$LOGFILE" | sort | uniq -c | sort -nr | head -1 | awk '{print $2" - "$1" requests"}'

echo "Top 3 IP Addresses:"
awk '{print $1}' "$LOGFILE" | sort | uniq -c | sort -nr | head -3 | awk '{print NR". "$2" - "$1" requests"}'
